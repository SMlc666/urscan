#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string_view>

// The UR_ENABLE_MULTITHREADING macro is the switch to enable/disable parallelism.
// It can be defined by the user, e.g., via the -D compiler flag.
#define UR_ENABLE_MULTITHREADING

// The UR_ENABLE_NEON_OPTIMIZATION macro is the switch to enable/disable NEON SIMD acceleration.
// It is only effective on ARM architectures that support NEON.
#define UR_ENABLE_NEON_OPTIMIZATION

#ifdef UR_ENABLE_MULTITHREADING
#include "thread_pool.hpp"
#include <future>
#include <vector>
#include <atomic>
#endif

#if defined(UR_ENABLE_NEON_OPTIMIZATION) && defined(__ARM_NEON)
#include <arm_neon.h>
#endif

namespace ur {

// A wrapper for C++20 string literal template parameters.
template<size_t N>
struct fixed_string {
    constexpr fixed_string(const char (&str)[N]) {
        std::copy_n(str, N, value);
    }
    char value[N];
    static constexpr size_t size = N - 1; // Exclude null terminator
    constexpr operator std::string_view() const { return {value, size}; }
};

// Represents a byte in the pattern, which can be a wildcard.
struct pattern_byte {
    std::byte value{};
    bool is_wildcard = false;
};

// npos constant for compatibility.
inline constexpr uintptr_t npos = static_cast<uintptr_t>(-1);

template<fixed_string S>
class signature {
private:
    // Compile-time calculation of the final pattern size.
    static consteval size_t get_pattern_size() {
        size_t count = 0;
        for (size_t i = 0; i < S.size; ++i) {
            if (S.value[i] == ' ') continue;
            if (S.value[i] == '?') {
                count++;
                if (i + 1 < S.size && S.value[i+1] == '?') i++;
            } else {
                count++;
                if (i + 1 < S.size) i++;
            }
        }
        return count;
    }

    // Compile-time parsing and validation of the pattern.
    static consteval auto parse_pattern() {
        constexpr size_t pattern_size = get_pattern_size();
        std::array<pattern_byte, pattern_size> p{};
        size_t p_idx = 0;

        auto hex_to_val = [](char c) -> std::uint8_t {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            throw "Invalid hexadecimal character in signature string.";
        };

        for (size_t i = 0; i < S.size; ++i) {
            if (S.value[i] == ' ') continue;

            if (S.value[i] == '?') {
                p[p_idx++] = {.is_wildcard = true};
                if (i + 1 < S.size && S.value[i+1] == '?') i++;
            } else {
                if (i + 1 >= S.size) throw "Incomplete hex pair.";
                
                std::uint8_t high = hex_to_val(S.value[i++]);
                std::uint8_t low = hex_to_val(S.value[i]);
                
                p[p_idx++] = { .value = static_cast<std::byte>((high << 4) | low), .is_wildcard = false };
            }
        }
        if (p_idx != pattern_size) throw "Invalid characters in signature string.";
        return p;
    }

    static constexpr auto pattern = parse_pattern();

    // A helper to check for a full pattern match at a specific location.
    // Can be used to check a sub-pattern by providing an offset.
    static bool full_match_at(const std::byte* location, size_t pattern_offset = 0) {
        for (size_t i = pattern_offset; i < pattern.size(); ++i) {
            if (!pattern[i].is_wildcard && pattern[i].value != location[i]) {
                return false;
            }
        }
        return true;
    }

    // The core single-threaded scanning logic.
    static std::optional<uintptr_t> scan_single_threaded(std::span<const std::byte> memory_range, std::atomic<bool>* found_flag = nullptr) {
        if constexpr (pattern.empty()) return std::nullopt;
        if (memory_range.size() < pattern.size()) return std::nullopt;

        const auto scan_end = memory_range.data() + memory_range.size() - pattern.size();

        for (const std::byte* current_byte = memory_range.data(); current_byte <= scan_end; ++current_byte) {
            if (found_flag && found_flag->load(std::memory_order_relaxed)) {
                return std::nullopt;
            }
            if (full_match_at(current_byte)) {
                if (found_flag) {
                    found_flag->store(true, std::memory_order_relaxed);
                }
                return reinterpret_cast<uintptr_t>(current_byte);
            }
        }
        return std::nullopt;
    }

#if defined(UR_ENABLE_NEON_OPTIMIZATION) && defined(__ARM_NEON)
    // Compile-time properties for NEON optimization.
    struct neon_properties {
        bool all_wildcards = false;
        std::byte anchor_byte{};
        size_t anchor_offset = 0;
        std::array<std::byte, 16> pattern16{};
        std::array<std::byte, 16> mask16{};
    };

    // Extracts properties needed for NEON scan at compile time.
    static consteval auto get_neon_properties() {
        neon_properties props{};
        if constexpr (pattern.empty()) {
            props.all_wildcards = true;
            return props;
        }

        bool found_anchor = false;
        for (size_t i = 0; i < pattern.size(); ++i) {
            if (!pattern[i].is_wildcard) {
                if (!found_anchor) {
                    props.anchor_byte = pattern[i].value;
                    props.anchor_offset = i;
                    found_anchor = true;
                }
            }
        }
        if (!found_anchor) {
            props.all_wildcards = true;
            return props;
        }

        for (size_t i = 0; i < 16 && i < pattern.size(); ++i) {
            if (pattern[i].is_wildcard) {
                props.pattern16[i] = std::byte{0};
                props.mask16[i] = std::byte{0};
            } else {
                props.pattern16[i] = pattern[i].value;
                props.mask16[i] = std::byte{0xFF};
            }
        }
        return props;
    }

    static constexpr auto neon_props = get_neon_properties();

    // The NEON-optimized scanning logic with corrected two-stage verification.
    static std::optional<uintptr_t> scan_neon(std::span<const std::byte> memory_range, std::atomic<bool>* found_flag = nullptr) {
        if constexpr (pattern.empty() || neon_props.all_wildcards) {
            return scan_single_threaded(memory_range, found_flag);
        }
        if (memory_range.size() < pattern.size()) return std::nullopt;

        const uint8x16_t v_anchor = vdupq_n_u8(static_cast<uint8_t>(neon_props.anchor_byte));
        const uint8x16_t v_pattern16 = vld1q_u8(reinterpret_cast<const uint8_t*>(neon_props.pattern16.data()));
        const uint8x16_t v_mask16 = vld1q_u8(reinterpret_cast<const uint8_t*>(neon_props.mask16.data()));

        const std::byte* current_pos = memory_range.data();
        const std::byte* const end_pos = memory_range.data() + memory_range.size() - pattern.size();
        const std::byte* const fast_scan_end_pos = memory_range.data() + memory_range.size() - 16;

        while (current_pos <= fast_scan_end_pos) {
            if (found_flag && found_flag->load(std::memory_order_relaxed)) {
                return std::nullopt;
            }
            const uint8x16_t v_mem = vld1q_u8(reinterpret_cast<const uint8_t*>(current_pos));
            const uint8x16_t v_cmp_result = vceqq_u8(v_mem, v_anchor);
            
            if (vmaxvq_u8(v_cmp_result) == 0) {
                current_pos += 16;
                continue;
            }

            uint8_t result_bytes[16];
            vst1q_u8(result_bytes, v_cmp_result);

            for (int i = 0; i < 16; ++i) {
                if (result_bytes[i] == 0xFF) { // Anchor byte found
                    const std::byte* potential_start = current_pos + i - neon_props.anchor_offset;
                    
                    if (potential_start < memory_range.data() || potential_start > end_pos) {
                        continue;
                    }

                    // Stage 2: 16-byte vectorized verification
                    const uint8x16_t v_mem16 = vld1q_u8(reinterpret_cast<const uint8_t*>(potential_start));
                    const uint8x16_t v_masked_mem = vandq_u8(v_mem16, v_mask16);
                    const uint8x16_t v_verify_result = vceqq_u8(v_masked_mem, v_pattern16);
                    
                    // CRITICAL FIX: Use vminvq_u8 to check if ALL bytes match, not just one.
                    if (vminvq_u8(v_verify_result) == 0xFF) {
                        // Stage 3: Full scalar verification for patterns > 16 bytes
                        if (pattern.size() <= 16 || full_match_at(potential_start, 16)) {
                            if (found_flag) {
                                found_flag->store(true, std::memory_order_relaxed);
                            }
                            return reinterpret_cast<uintptr_t>(potential_start);
                        }
                    }
                }
            }
            current_pos += 16;
        }

        // Handle the tail part of the memory range that is smaller than 16 bytes.
        std::span<const std::byte> tail_span{current_pos, static_cast<size_t>(memory_range.data() + memory_range.size() - current_pos)};
        if (auto tail_result = scan_single_threaded(tail_span, found_flag)) {
            return tail_result;
        }

        return std::nullopt;
    }
#endif

#ifdef UR_ENABLE_MULTITHREADING
    // Provides a singleton instance of the thread pool.
    static ThreadPool& get_pool() {
        static ThreadPool pool;
        return pool;
    }
#endif

public:
    static std::optional<uintptr_t> scan(std::span<const std::byte> memory_range) {
        using scanner_func_t = std::optional<uintptr_t>(*)(std::span<const std::byte>, std::atomic<bool>*);
        scanner_func_t core_scanner = &scan_single_threaded;

#if defined(UR_ENABLE_NEON_OPTIMIZATION) && defined(__ARM_NEON)
        core_scanner = &scan_neon;
#endif

#ifdef UR_ENABLE_MULTITHREADING
        if constexpr (pattern.empty()) return std::nullopt;
        if (memory_range.size() < pattern.size()) return std::nullopt;

        const unsigned int num_threads = std::thread::hardware_concurrency();
        const size_t min_range_for_multithread = pattern.size() * num_threads * 10;

        if (num_threads <= 1 || memory_range.size() < min_range_for_multithread) {
            return core_scanner(memory_range, nullptr);
        }

        auto& pool = get_pool();
        std::vector<std::future<std::optional<uintptr_t>>> futures;
        std::atomic<bool> found_flag = false;
        const size_t chunk_size = memory_range.size() / num_threads;
        const size_t overlap = pattern.size() > 1 ? pattern.size() - 1 : 0;

        for (unsigned int i = 0; i < num_threads; ++i) {
            size_t start = i * chunk_size;
            size_t end = (i == num_threads - 1) ? memory_range.size() : (start + chunk_size + overlap);
            
            if (end > memory_range.size()) end = memory_range.size();
            if (start >= end || (end - start) < pattern.size()) continue;

            std::span<const std::byte> chunk = memory_range.subspan(start, end - start);
            futures.push_back(pool.enqueue(core_scanner, chunk, &found_flag));
        }

        for (auto& fut : futures) {
            if (auto result = fut.get(); result.has_value()) {
                return result;
            }
        }
        return std::nullopt;
#else
        return core_scanner(memory_range, nullptr);
#endif
    }
};

} // namespace ur